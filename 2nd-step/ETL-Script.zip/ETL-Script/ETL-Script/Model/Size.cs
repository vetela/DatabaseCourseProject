﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Size
{
    public int Sizeid { get; set; }

    public decimal? Ussize { get; set; }

    public decimal? Uksize { get; set; }

    public decimal? Eursize { get; set; }

    public decimal? Cmsize { get; set; }

    public decimal? Brsize { get; set; }

    public decimal? Cnsize { get; set; }

    public virtual ICollection<Productsize> Productsizes { get; set; } = new List<Productsize>();
}

﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Orderdetail
{
    public int Orderdetailid { get; set; }

    public int? Orderid { get; set; }

    public int? Productsizeid { get; set; }

    public int Quantity { get; set; }

    public decimal Price { get; set; }

    public virtual Order? Order { get; set; }

    public virtual Productsize? Productsize { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Paymentmethod
{
    public int Paymentmethodid { get; set; }

    public string Methodname { get; set; } = null!;

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
}

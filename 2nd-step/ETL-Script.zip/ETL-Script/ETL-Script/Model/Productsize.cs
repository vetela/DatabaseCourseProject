﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Productsize
{
    public int Productsizeid { get; set; }

    public int? Productid { get; set; }

    public int? Sizeid { get; set; }

    public int Stockquantity { get; set; }

    public virtual ICollection<Orderdetail> Orderdetails { get; set; } = new List<Orderdetail>();

    public virtual Product? Product { get; set; }

    public virtual ICollection<Shoppingcartitem> Shoppingcartitems { get; set; } = new List<Shoppingcartitem>();

    public virtual Size? Size { get; set; }
}

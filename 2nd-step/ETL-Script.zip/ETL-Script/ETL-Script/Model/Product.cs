﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Product
{
    public int Productid { get; set; }

    public string Productname { get; set; } = null!;

    public string? Description { get; set; }

    public decimal Price { get; set; }

    public int? Categoryid { get; set; }

    public int? Brandid { get; set; }

    public virtual Brand? Brand { get; set; }

    public virtual Category? Category { get; set; }

    public virtual ICollection<Productsize> Productsizes { get; set; } = new List<Productsize>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}

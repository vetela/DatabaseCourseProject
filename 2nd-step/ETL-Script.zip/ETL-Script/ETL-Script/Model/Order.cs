﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Order
{
    public int Orderid { get; set; }

    public int? Userid { get; set; }

    public DateTime Orderdate { get; set; }

    public decimal Totalamount { get; set; }

    public int? Statusid { get; set; }

    public virtual ICollection<Orderdetail> Orderdetails { get; set; } = new List<Orderdetail>();

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    public virtual Orderstatus? Status { get; set; }

    public virtual User? User { get; set; }
}

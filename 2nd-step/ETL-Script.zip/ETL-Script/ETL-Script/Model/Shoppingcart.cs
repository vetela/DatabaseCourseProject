﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Shoppingcart
{
    public int Cartid { get; set; }

    public int? Userid { get; set; }

    public virtual ICollection<Shoppingcartitem> Shoppingcartitems { get; set; } = new List<Shoppingcartitem>();

    public virtual User? User { get; set; }
}

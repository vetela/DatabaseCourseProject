﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model;

public partial class Shoppingcartitem
{
    public int Cartitemid { get; set; }

    public int? Cartid { get; set; }

    public int? Productsizeid { get; set; }

    public int Quantity { get; set; }

    public virtual Shoppingcart? Cart { get; set; }

    public virtual Productsize? Productsize { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Dimcustomer
{
    public int Customerid { get; set; }

    public string Username { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Address { get; set; }

    public string? Phone { get; set; }

    public int? Roleid { get; set; }

    public virtual ICollection<Factsale> Factsales { get; set; } = new List<Factsale>();

    public virtual Dimrole? Role { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Dimorderstatus
{
    public int Statusid { get; set; }

    public string Statusname { get; set; } = null!;
}

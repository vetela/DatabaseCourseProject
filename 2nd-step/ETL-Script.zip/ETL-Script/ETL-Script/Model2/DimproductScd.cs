﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class DimproductScd
{
    public int Productscdid { get; set; }

    public int? Productid { get; set; }

    public string Productname { get; set; } = null!;

    public string? Description { get; set; }

    public decimal Price { get; set; }

    public int? Categoryid { get; set; }

    public int? Brandid { get; set; }

    public DateOnly Effectivedate { get; set; }

    public DateOnly? Expirationdate { get; set; }

    public bool Iscurrent { get; set; }

    public virtual Dimbrand? Brand { get; set; }

    public virtual Dimcategory? Category { get; set; }
}

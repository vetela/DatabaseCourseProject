﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Dimrole
{
    public int Roleid { get; set; }

    public string Rolename { get; set; } = null!;

    public virtual ICollection<Dimcustomer> Dimcustomers { get; set; } = new List<Dimcustomer>();
}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ETL_Script.Model2;

public partial class FootballBootsStoreOlapContext : DbContext
{
    public FootballBootsStoreOlapContext()
    {
    }

    public FootballBootsStoreOlapContext(DbContextOptions<FootballBootsStoreOlapContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Dimbrand> Dimbrands { get; set; }

    public virtual DbSet<Dimcategory> Dimcategories { get; set; }

    public virtual DbSet<Dimcustomer> Dimcustomers { get; set; }

    public virtual DbSet<Dimdate> Dimdates { get; set; }

    public virtual DbSet<Dimorderstatus> Dimorderstatuses { get; set; }

    public virtual DbSet<Dimproduct> Dimproducts { get; set; }

    public virtual DbSet<DimproductScd> DimproductScds { get; set; }

    public virtual DbSet<Dimrole> Dimroles { get; set; }

    public virtual DbSet<Dimsize> Dimsizes { get; set; }

    public virtual DbSet<Factinventory> Factinventories { get; set; }

    public virtual DbSet<Factsale> Factsales { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("User ID=postgres;Password=*****;Host=localhost;Port=5432;Database=FootballBootsStoreOLAP;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Dimbrand>(entity =>
        {
            entity.HasKey(e => e.Brandid).HasName("dimbrand_pkey");

            entity.ToTable("dimbrand");

            entity.Property(e => e.Brandid).HasColumnName("brandid");
            entity.Property(e => e.Brandname)
                .HasMaxLength(100)
                .HasColumnName("brandname");
        });

        modelBuilder.Entity<Dimcategory>(entity =>
        {
            entity.HasKey(e => e.Categoryid).HasName("dimcategory_pkey");

            entity.ToTable("dimcategory");

            entity.Property(e => e.Categoryid).HasColumnName("categoryid");
            entity.Property(e => e.Categoryname)
                .HasMaxLength(100)
                .HasColumnName("categoryname");
        });

        modelBuilder.Entity<Dimcustomer>(entity =>
        {
            entity.HasKey(e => e.Customerid).HasName("dimcustomer_pkey");

            entity.ToTable("dimcustomer");

            entity.Property(e => e.Customerid).HasColumnName("customerid");
            entity.Property(e => e.Address)
                .HasMaxLength(255)
                .HasColumnName("address");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.Phone)
                .HasMaxLength(20)
                .HasColumnName("phone");
            entity.Property(e => e.Roleid).HasColumnName("roleid");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .HasColumnName("username");

            entity.HasOne(d => d.Role).WithMany(p => p.Dimcustomers)
                .HasForeignKey(d => d.Roleid)
                .HasConstraintName("dimcustomer_roleid_fkey");
        });

        modelBuilder.Entity<Dimdate>(entity =>
        {
            entity.HasKey(e => e.Dateid).HasName("dimdate_pkey");

            entity.ToTable("dimdate");

            entity.Property(e => e.Dateid).HasColumnName("dateid");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.Day).HasColumnName("day");
            entity.Property(e => e.Month).HasColumnName("month");
            entity.Property(e => e.Week).HasColumnName("week");
            entity.Property(e => e.Year).HasColumnName("year");
        });

        modelBuilder.Entity<Dimorderstatus>(entity =>
        {
            entity.HasKey(e => e.Statusid).HasName("dimorderstatus_pkey");

            entity.ToTable("dimorderstatus");

            entity.Property(e => e.Statusid).HasColumnName("statusid");
            entity.Property(e => e.Statusname)
                .HasMaxLength(50)
                .HasColumnName("statusname");
        });

        modelBuilder.Entity<Dimproduct>(entity =>
        {
            entity.HasKey(e => e.Productid).HasName("dimproduct_pkey");

            entity.ToTable("dimproduct");

            entity.Property(e => e.Productid).HasColumnName("productid");
            entity.Property(e => e.Brandid).HasColumnName("brandid");
            entity.Property(e => e.Categoryid).HasColumnName("categoryid");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Price)
                .HasPrecision(10, 2)
                .HasColumnName("price");
            entity.Property(e => e.Productname)
                .HasMaxLength(100)
                .HasColumnName("productname");

            entity.HasOne(d => d.Brand).WithMany(p => p.Dimproducts)
                .HasForeignKey(d => d.Brandid)
                .HasConstraintName("dimproduct_brandid_fkey");

            entity.HasOne(d => d.Category).WithMany(p => p.Dimproducts)
                .HasForeignKey(d => d.Categoryid)
                .HasConstraintName("dimproduct_categoryid_fkey");
        });

        modelBuilder.Entity<DimproductScd>(entity =>
        {
            entity.HasKey(e => e.Productscdid).HasName("dimproduct_scd_pkey");

            entity.ToTable("dimproduct_scd");

            entity.Property(e => e.Productscdid).HasColumnName("productscdid");
            entity.Property(e => e.Brandid).HasColumnName("brandid");
            entity.Property(e => e.Categoryid).HasColumnName("categoryid");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Effectivedate).HasColumnName("effectivedate");
            entity.Property(e => e.Expirationdate).HasColumnName("expirationdate");
            entity.Property(e => e.Iscurrent).HasColumnName("iscurrent");
            entity.Property(e => e.Price)
                .HasPrecision(10, 2)
                .HasColumnName("price");
            entity.Property(e => e.Productid).HasColumnName("productid");
            entity.Property(e => e.Productname)
                .HasMaxLength(100)
                .HasColumnName("productname");

            entity.HasOne(d => d.Brand).WithMany(p => p.DimproductScds)
                .HasForeignKey(d => d.Brandid)
                .HasConstraintName("dimproduct_scd_brandid_fkey");

            entity.HasOne(d => d.Category).WithMany(p => p.DimproductScds)
                .HasForeignKey(d => d.Categoryid)
                .HasConstraintName("dimproduct_scd_categoryid_fkey");
        });

        modelBuilder.Entity<Dimrole>(entity =>
        {
            entity.HasKey(e => e.Roleid).HasName("dimrole_pkey");

            entity.ToTable("dimrole");

            entity.Property(e => e.Roleid).HasColumnName("roleid");
            entity.Property(e => e.Rolename)
                .HasMaxLength(50)
                .HasColumnName("rolename");
        });

        modelBuilder.Entity<Dimsize>(entity =>
        {
            entity.HasKey(e => e.Sizeid).HasName("dimsize_pkey");

            entity.ToTable("dimsize");

            entity.Property(e => e.Sizeid).HasColumnName("sizeid");
            entity.Property(e => e.Brsize)
                .HasPrecision(4, 1)
                .HasColumnName("brsize");
            entity.Property(e => e.Cmsize)
                .HasPrecision(4, 1)
                .HasColumnName("cmsize");
            entity.Property(e => e.Cnsize)
                .HasPrecision(4, 1)
                .HasColumnName("cnsize");
            entity.Property(e => e.Eursize)
                .HasPrecision(4, 1)
                .HasColumnName("eursize");
            entity.Property(e => e.Uksize)
                .HasPrecision(4, 1)
                .HasColumnName("uksize");
            entity.Property(e => e.Ussize)
                .HasPrecision(4, 1)
                .HasColumnName("ussize");
        });

        modelBuilder.Entity<Factinventory>(entity =>
        {
            entity.HasKey(e => e.Inventoryid).HasName("factinventory_pkey");

            entity.ToTable("factinventory");

            entity.Property(e => e.Inventoryid).HasColumnName("inventoryid");
            entity.Property(e => e.Dateid).HasColumnName("dateid");
            entity.Property(e => e.Productid).HasColumnName("productid");
            entity.Property(e => e.Sizeid).HasColumnName("sizeid");
            entity.Property(e => e.Stockquantity).HasColumnName("stockquantity");

            entity.HasOne(d => d.Date).WithMany(p => p.Factinventories)
                .HasForeignKey(d => d.Dateid)
                .HasConstraintName("factinventory_dateid_fkey");

            entity.HasOne(d => d.Product).WithMany(p => p.Factinventories)
                .HasForeignKey(d => d.Productid)
                .HasConstraintName("factinventory_productid_fkey");

            entity.HasOne(d => d.Size).WithMany(p => p.Factinventories)
                .HasForeignKey(d => d.Sizeid)
                .HasConstraintName("factinventory_sizeid_fkey");
        });

        modelBuilder.Entity<Factsale>(entity =>
        {
            entity.HasKey(e => e.Salesid).HasName("factsales_pkey");

            entity.ToTable("factsales");

            entity.Property(e => e.Salesid).HasColumnName("salesid");
            entity.Property(e => e.Customerid).HasColumnName("customerid");
            entity.Property(e => e.Dateid).HasColumnName("dateid");
            entity.Property(e => e.Productid).HasColumnName("productid");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.Sizeid).HasColumnName("sizeid");
            entity.Property(e => e.Totalamount)
                .HasPrecision(10, 2)
                .HasColumnName("totalamount");

            entity.HasOne(d => d.Customer).WithMany(p => p.Factsales)
                .HasForeignKey(d => d.Customerid)
                .HasConstraintName("factsales_customerid_fkey");

            entity.HasOne(d => d.Date).WithMany(p => p.Factsales)
                .HasForeignKey(d => d.Dateid)
                .HasConstraintName("factsales_dateid_fkey");

            entity.HasOne(d => d.Product).WithMany(p => p.Factsales)
                .HasForeignKey(d => d.Productid)
                .HasConstraintName("factsales_productid_fkey");

            entity.HasOne(d => d.Size).WithMany(p => p.Factsales)
                .HasForeignKey(d => d.Sizeid)
                .HasConstraintName("factsales_sizeid_fkey");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

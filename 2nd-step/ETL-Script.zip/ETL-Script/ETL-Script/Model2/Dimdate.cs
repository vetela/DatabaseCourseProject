﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Dimdate
{
    public int Dateid { get; set; }

    public DateOnly Date { get; set; }

    public int Year { get; set; }

    public int Month { get; set; }

    public int Day { get; set; }

    public int Week { get; set; }

    public virtual ICollection<Factinventory> Factinventories { get; set; } = new List<Factinventory>();

    public virtual ICollection<Factsale> Factsales { get; set; } = new List<Factsale>();
}

﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Dimbrand
{
    public int Brandid { get; set; }

    public string Brandname { get; set; } = null!;

    public virtual ICollection<DimproductScd> DimproductScds { get; set; } = new List<DimproductScd>();

    public virtual ICollection<Dimproduct> Dimproducts { get; set; } = new List<Dimproduct>();
}

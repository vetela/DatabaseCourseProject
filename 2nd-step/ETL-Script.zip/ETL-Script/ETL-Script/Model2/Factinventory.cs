﻿using System;
using System.Collections.Generic;

namespace ETL_Script.Model2;

public partial class Factinventory
{
    public int Inventoryid { get; set; }

    public int? Dateid { get; set; }

    public int? Productid { get; set; }

    public int? Sizeid { get; set; }

    public int Stockquantity { get; set; }

    public virtual Dimdate? Date { get; set; }

    public virtual Dimproduct? Product { get; set; }

    public virtual Dimsize? Size { get; set; }
}

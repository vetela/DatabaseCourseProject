﻿using ETL_Script.ETL;
using ETL_Script.Model;
using ETL_Script.Model2;

internal class Program
{
	private static void Main(string[] args)
	{
		var oltpContext = new FotballBootsStoreContext();
		var olapContex = new FootballBootsStoreOlapContext(); 
		var etlProcess = new ETLProcess(oltpContext, olapContex);
		etlProcess.Run();
	}
}
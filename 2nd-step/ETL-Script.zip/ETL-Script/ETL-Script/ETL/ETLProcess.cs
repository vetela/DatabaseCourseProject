﻿using ETL_Script.Model;
using ETL_Script.Model2;
using Microsoft.EntityFrameworkCore;
using System;
using System.Globalization;

namespace ETL_Script.ETL
{
	public class ETLProcess
	{
		private readonly FotballBootsStoreContext _oltpContext;
		private readonly FootballBootsStoreOlapContext _olapContext;

		public ETLProcess(FotballBootsStoreContext oltpContext, FootballBootsStoreOlapContext olapContext)
		{
			_oltpContext = oltpContext;
			_olapContext = olapContext;
		}

		public void Run()
		{
			ExtractAndLoadRoles();
			ExtractAndLoadCustomers();
			ExtractAndLoadCategories();
			ExtractAndLoadBrands();
			ExtractAndLoadProducts();
			ExtractAndLoadSizes();
			ExtractAndLoadInventory();
			ExtractAndLoadSales();
		}

		private void ExtractAndLoadRoles()
		{
			var roles = _oltpContext.Roles.ToList();
			var existingRoleIDs = _olapContext.Dimroles.Select(r => r.Roleid).ToHashSet();

			var newRoles = roles.Where(r => !existingRoleIDs.Contains(r.Roleid))
				.Select(r => new Dimrole
				{
					Roleid = r.Roleid,
					Rolename = r.Rolename
				}).ToList();

			if (newRoles.Any())
			{
				_olapContext.Dimroles.AddRange(newRoles);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadCustomers()
		{
			var users = _oltpContext.Users.ToList();
			var existingCustomerIDs = _olapContext.Dimcustomers.Select(c => c.Customerid).ToHashSet();

			var newCustomers = users.Where(u => !existingCustomerIDs.Contains(u.Userid))
				.Select(u => new Dimcustomer
				{
					Customerid = u.Userid,
					Username = u.Username,
					Email = u.Email,
					Address = u.Address,
					Phone = u.Phone,
					Roleid = u.Roleid
				}).ToList();

			if (newCustomers.Any())
			{
				_olapContext.Dimcustomers.AddRange(newCustomers);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadCategories()
		{
			var categories = _oltpContext.Categories.ToList();
			var existingCategoryIDs = _olapContext.Dimcategories.Select(c => c.Categoryid).ToHashSet();

			var newCategories = categories.Where(c => !existingCategoryIDs.Contains(c.Categoryid))
				.Select(c => new Dimcategory
				{
					Categoryid = c.Categoryid,
					Categoryname = c.Categoryname
				}).ToList();

			if (newCategories.Any())
			{
				_olapContext.Dimcategories.AddRange(newCategories);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadBrands()
		{
			var brands = _oltpContext.Brands.ToList();
			var existingBrandIDs = _olapContext.Dimbrands.Select(b => b.Brandid).ToHashSet();

			var newBrands = brands.Where(b => !existingBrandIDs.Contains(b.Brandid))
				.Select(b => new Dimbrand
				{
					Brandid = b.Brandid,
					Brandname = b.Brandname
				}).ToList();

			if (newBrands.Any())
			{
				_olapContext.Dimbrands.AddRange(newBrands);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadProducts()
		{
			var products = _oltpContext.Products.ToList();
			var existingProductIDs = _olapContext.Dimproducts.Select(p => p.Productid).ToHashSet();

			var newProducts = products.Where(p => !existingProductIDs.Contains(p.Productid))
				.Select(p => new Dimproduct
				{
					Productid = p.Productid,
					Productname = p.Productname,
					Description = p.Description,
					Price = p.Price,
					Categoryid = p.Categoryid,
					Brandid = p.Brandid
				}).ToList();

			var newProductSCDs = products.Where(p => !existingProductIDs.Contains(p.Productid))
				.Select(p => new DimproductScd
				{
					Productid = p.Productid,
					Productname = p.Productname,
					Description = p.Description,
					Price = p.Price,
					Categoryid = p.Categoryid,
					Brandid = p.Brandid,
					Effectivedate = DateOnly.FromDateTime(DateTime.Now),
					Iscurrent = true
				}).ToList();

			if (newProducts.Any())
			{
				_olapContext.Dimproducts.AddRange(newProducts);
				_olapContext.DimproductScds.AddRange(newProductSCDs);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadSizes()
		{
			var sizes = _oltpContext.Sizes.ToList();
			var existingSizeIDs = _olapContext.Dimsizes.Select(s => s.Sizeid).ToHashSet();

			var newSizes = sizes.Where(s => !existingSizeIDs.Contains(s.Sizeid))
				.Select(s => new Dimsize
				{
					Sizeid = s.Sizeid,
					Ussize = s.Ussize,
					Uksize = s.Uksize,
					Eursize = s.Eursize,
					Cmsize = s.Cmsize,
					Brsize = s.Brsize,
					Cnsize = s.Cnsize
				}).ToList();

			if (newSizes.Any())
			{
				_olapContext.Dimsizes.AddRange(newSizes);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadSales()
		{
			var orders = _oltpContext.Orders.Include(o => o.Orderdetails).ToList();
			var existingSalesIDs = _olapContext.Factsales.Select(s => s.Salesid).ToHashSet();
			var newFactSales = new List<Factsale>();

			foreach (var order in orders)
			{
				foreach (var orderDetail in order.Orderdetails)
				{
					if (!existingSalesIDs.Contains(orderDetail.Orderdetailid))
					{
						newFactSales.Add(new Factsale
						{
							Dateid = GetDateID(order.Orderdate),
							Productid = orderDetail.Productsize.Productid,
							Sizeid = _oltpContext.Productsizes.FirstOrDefault(ps => ps.Productsizeid == orderDetail.Productsizeid).Sizeid,
							Customerid = order.Userid,
							Quantity = orderDetail.Quantity,
							Totalamount = orderDetail.Quantity * orderDetail.Price
						});
					}
				}
			}

			if (newFactSales.Any())
			{
				_olapContext.Factsales.AddRange(newFactSales);
				_olapContext.SaveChanges();
			}
		}

		private void ExtractAndLoadInventory()
		{
			var productSizes = _oltpContext.Productsizes.ToList();
			var existingInventoryIDs = _olapContext.Factinventories.Select(i => i.Inventoryid).ToHashSet();

			var newFactInventory = productSizes.Where(ps => !existingInventoryIDs.Contains(ps.Productsizeid))
				.Select(ps => new Factinventory
				{
					Dateid = GetDateID(DateTime.Now),
					Productid = ps.Productid,
					Sizeid = ps.Sizeid,
					Stockquantity = ps.Stockquantity
				}).ToList();

			if (newFactInventory.Any())
			{
				_olapContext.Factinventories.AddRange(newFactInventory);
				_olapContext.SaveChanges();
			}
		}

		private int GetDateID(DateTime date)
		{
			var dimDate = _olapContext.Dimdates.FirstOrDefault(d => d.Date == DateOnly.FromDateTime(date));
			if (dimDate != null)
			{
				return dimDate.Dateid;
			}

			dimDate = new Dimdate
			{
				Date = DateOnly.FromDateTime(date),
				Year = date.Year,
				Month = date.Month,
				Day = date.Day,
				Week = CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(date, CalendarWeekRule.FirstDay, DayOfWeek.Monday)
			};

			_olapContext.Dimdates.Add(dimDate);
			_olapContext.SaveChanges();

			return dimDate.Dateid;
		}
	}
}
